'use strict';

var request = require('request');
var crypto = require('crypto-js');

//const endpoint_url = process.env['ENDPOINT_URL'];

module.exports.handler = (event, context, callback) => {
    console.log(JSON.stringify(event));
    
    callback(
        null,
        'Hello from getUser'
    );
}
